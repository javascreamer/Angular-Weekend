import { Component } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product',
  imports: [],
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent {

  constructor(private productService:ProductService){

  }

  fetchProducts(){
     this.productService.getProducts().subscribe(
        (response) =>{
               console.log(response);
        },
        (error) =>{
          console.log(error);
        }
     )
  }



}
