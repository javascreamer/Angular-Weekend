import { CommonModule } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../admin.service';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent {

  @ViewChild('myFormSection') myFormSection!: ElementRef;

  notification = false;
  message:string = "";

  constructor(private adminService:AdminService,private productService:ProductService, private router:Router){

  }

   product= {
    productId : "",
    productName : "",
    productDescription:"" ,
    productPrice: "",
    productURL: "",
    category: ""
   }

   updateProductFlag:boolean = false;

   addProduct(){
       console.log(this.product);

        this.adminService.addProductToDB(this.product).subscribe(
          {
             next: (response:any) => {
              console.log(response)
               if(response.status){
                      this.notification = true;
                      this.message = "The Product added successfully";
                       this.product = {
                        productId : "",
                        productName : "",
                        productDescription:"" ,
                        productPrice: "",
                        productURL: "",
                        category: ""
                       }
                    
                      
               }
            },
             error: error => console.log(error),
             complete: ()=> {console.log("operation completed")}

          }
        )

        
   }

   saveProduct(){
     this.adminService.updateProductinDB(this.product).subscribe(
      {
        next: (response:any) =>{
          console.log(response);

           this.updateProductFlag = false;
           this.notification = true;
           this.message = "The product updated successfully!";
           this.product = {
            productId : "",
            productName : "",
            productDescription:"" ,
            productPrice: "",
            productURL: "",
            category: ""
           }

           if(response.status){
                    this.getProductsList();
           }
  },
  error : (error:any) => console.log(error),
  complete: () => console.log("operation complete")
      }
     )
   }

   editProduct(product:any){
           console.log(product);
           this.updateProductFlag = true;
            this.product = product;
            this.myFormSection.nativeElement.scrollIntoView({ behavior: 'smooth' });
   }

   productList:any= [];

   
 
   ngOnInit(): void {
       this.getProductsList()
   }

   private getProductsList(){
    this.productService.getProducts().subscribe(
      response =>{
        console.log(response);
        this.productList = response;
      }
     )
   }
 
   viewProduct(productId:any){
    console.log("productId", productId);
    localStorage.setItem("productId",productId);
    // redirection logic?
    this.router.navigateByUrl("productview");
   }

   deleteProduct(productId:any){

     this.adminService.deleteProductFromDB(productId).subscribe({
      next: (response:any) =>{
              console.log(response);

               if(response.status){
                        this.getProductsList();
               }
      },
      error : (error:any) => console.log(error),
      complete: () => console.log("operation complete")
     }
          
     )


   }

}
