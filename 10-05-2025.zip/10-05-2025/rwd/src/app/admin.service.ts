import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private httpClient:HttpClient) { }

   addProductToDB(product:any){
          return this.httpClient.post("http://localhost:3019/api/addProduct",product);
   }

   deleteProductFromDB(productId:any){
            return this.httpClient.delete("http://localhost:3019/api/deleteProductById/"+productId)
   }

   updateProductinDB(product:any){
           return this.httpClient.put("http://localhost:3019/api/editProductById/"+product.productId,product);
   }

}
