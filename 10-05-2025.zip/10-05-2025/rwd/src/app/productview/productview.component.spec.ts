import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductviewComponent } from './productview.component';
import { provideHttpClientTesting } from '@angular/common/http/testing';

describe('ProductviewComponent', () => {
  let component: ProductviewComponent;
  let fixture: ComponentFixture<ProductviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductviewComponent],
      providers: [
        provideHttpClientTesting()  // ✅ Replaces HttpClientTestingModule
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
