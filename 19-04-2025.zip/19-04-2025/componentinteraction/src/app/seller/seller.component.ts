import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-seller',
  imports: [],
  templateUrl: './seller.component.html',
  styleUrl: './seller.component.css'
})
export class SellerComponent {

   sellerInfo = {
       name: "Net Retail Pvt Ltd",
       location: "hyderabad", 
       pincode: 500043
   }

   @Output() sellerDataEvent = new EventEmitter();

   sendInfo(){

      this.sellerDataEvent.emit(this.sellerInfo);

   }


}
