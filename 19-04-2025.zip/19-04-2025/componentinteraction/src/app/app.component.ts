import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ProductComponent } from './product/product.component';
import { SellerComponent } from './seller/seller.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,ProductComponent,SellerComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'componentinteraction';

   product = {
           name: "product 1", 
           price: 2000
   }

   sellerInfoDetails:any;

   typeOfInput= "text";
   placeholderText = "enter username";

   captureSeller(info:any){
             console.log(info);
             this.sellerInfoDetails = info;
   }

}
