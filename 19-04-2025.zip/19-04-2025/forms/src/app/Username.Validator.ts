import { AbstractControl, ValidationErrors } from "@angular/forms";

export class UsernameValidator{


     static cannotHaveSpace(control:AbstractControl):ValidationErrors | null {

           if(control.value.includes(" ")){
            return {
                cannotHaveSpace:true
            }
           }
           else{
            return {
                cannotHaveSpace:false
            }
           }

     }

     static cannotHaveSpecialCharacters(control:AbstractControl):ValidationErrors | null {
                 // Write the logic to check if the string has special chars or not
        if(control.value.includes(" ")){
         return {
             cannotHaveSpace:true
         }
        }
        else{
         return {
             cannotHaveSpace:false
         }
        }

  }

     
}