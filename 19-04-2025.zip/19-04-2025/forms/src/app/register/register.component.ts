import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UsernameValidator } from '../Username.Validator';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  form = new FormGroup(
    {

       username: new FormControl("",[Validators.required, Validators.minLength(5), Validators.maxLength(10), UsernameValidator.cannotHaveSpace]), 
       password:new FormControl("",),
       email: new FormControl("",)

    }
  )

  register(formData:any){
      console.log(formData.value);
  }

}
