
//boolean

class Datatypes{
        name:string;
        isEmployee:boolean;
        age:number;
        languagesKnown:string[];
        address:[string,number];
        data:any;
        
}

var datatypes = new Datatypes(); 
datatypes.name = "kiran";
datatypes.isEmployee = false;
datatypes.age=21;
datatypes.languagesKnown =["telugu"];
datatypes.address =["hyderabad",101];
datatypes.data=101;
datatypes.data="hello";

console.log(datatypes);

enum Roles{
     Developer="D", Tester="T", DevOpsEngineer="DE"
}
console.log(Roles);

console.log(Roles.DevOpsEngineer);

// Roles.DevOpsEngineer ="DOE";

// console.log(Roles.DevOpsEngineer);