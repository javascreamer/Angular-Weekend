
class Company{
     companyName:string; 
     companyaddress:string;

     constructor(companyName:string,companyaddress:string){
        this.companyName= companyName;
        this.companyaddress = companyaddress;
     }
}
class Employee extends Company{
      eid:number; 
      name:string;
      address:string;
      designation:string;
      constructor(eid:number, name:string, address:string, designation:string, companyName:string, companyaddress:string){
         super(companyName,companyaddress)
        this.eid = eid; 
         this.name= name; 
         this.address = address;
         this.designation = designation
      }
}
var emp1= new Employee(101,"abc","xyz","hks","intellpat","banglore");
console.log(emp1);
