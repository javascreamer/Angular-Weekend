

class A{

     a =100;

}

class B{

     b=200;

}

class C extends A,B{

}

var c= new C(); 
console.log(c.a);