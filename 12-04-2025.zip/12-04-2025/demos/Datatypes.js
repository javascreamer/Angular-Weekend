//boolean
var Datatypes = /** @class */ (function () {
    function Datatypes() {
    }
    return Datatypes;
}());
var datatypes = new Datatypes();
datatypes.name = "kiran";
datatypes.isEmployee = false;
datatypes.age = 21;
datatypes.languagesKnown = ["telugu"];
datatypes.address = ["hyderabad", 101];
datatypes.data = 101;
console.log(datatypes);
var Roles;
(function (Roles) {
    Roles["Developer"] = "D";
    Roles["Tester"] = "T";
    Roles["DevOpsEngineer"] = "DE";
})(Roles || (Roles = {}));
console.log(Roles);
console.log(Roles.DevOpsEngineer);
// Roles.DevOpsEngineer ="DOE";
// console.log(Roles.DevOpsEngineer);
