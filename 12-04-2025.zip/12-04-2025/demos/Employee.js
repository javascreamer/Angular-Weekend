var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Company = /** @class */ (function () {
    function Company(companyName, companyaddress) {
        this.companyName = companyName;
        this.companyaddress = companyaddress;
    }
    return Company;
}());
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(eid, name, address, designation, companyName, companyaddress) {
        var _this = _super.call(this, companyName, companyaddress) || this;
        _this.eid = eid;
        _this.name = name;
        _this.address = address;
        _this.designation = designation;
        return _this;
    }
    return Employee;
}(Company));
var emp1 = new Employee(101, "abc", "xyz", "hks", "intellpat", "banglore");
console.log(emp1);
