var Gmail = /** @class */ (function () {
    function Gmail() {
    }
    return Gmail;
}());
var LinkedIn = /** @class */ (function () {
    function LinkedIn() {
    }
    return LinkedIn;
}());
var UserImpl = /** @class */ (function () {
    function UserImpl() {
    }
    UserImpl.prototype.login = function (username, password) {
        if (username == "abc" && password == "abc") {
            console.log("login success");
        }
        else {
            console.log("login failure");
        }
    };
    UserImpl.prototype.loginWithGmail = function (gmail) {
    };
    UserImpl.prototype.loginwithLinkedIn = function (linkedIn) {
    };
    return UserImpl;
}());
var user1 = new UserImpl();
user1.login("abc", "abc123");
