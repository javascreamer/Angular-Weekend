var User = /** @class */ (function () {
    function User() {
    }
    User.prototype.login = function (param1, param2, param3) {
        if (typeof param1 == "string" && typeof param2 == "string") {
            console.log("Login mechanism with username and password");
        }
        if (typeof param1 == "number" && typeof param2 == "string") {
            console.log("Login mechanism with mobile and password");
        }
        if (typeof param1 == "number" && typeof param2 == "string" && typeof param3 == "number") {
            console.log("Login mechanism with email, password & otp");
        }
    };
    return User;
}());
var user = new User();
user.login(9010101010, "sai");
