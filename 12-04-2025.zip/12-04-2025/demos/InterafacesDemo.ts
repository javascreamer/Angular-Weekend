
class Gmail{

}

class LinkedIn{

}

interface User{

     login(username:string, password:string);
     loginWithGmail(gmail:Gmail);
     loginwithLinkedIn(linkedIn:LinkedIn);

}

class UserImpl implements User {

    login(username:string, password:string){
         
         if(username =="abc" && password =="abc"){
               console.log("login success");
         }
         else{
            console.log("login failure");
         }
    }
    loginWithGmail(gmail:Gmail){

    }
    loginwithLinkedIn(linkedIn:LinkedIn){

    }

}

var user1:User = new UserImpl();

user1.login("abc","abc123");

