import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { BuiltinpipesComponent } from './builtinpipes/builtinpipes.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,BuiltinpipesComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'pipesdemo';
}
