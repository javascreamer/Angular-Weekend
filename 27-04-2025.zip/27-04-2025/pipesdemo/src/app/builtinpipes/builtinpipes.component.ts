import { CommonModule, CurrencyPipe, DatePipe, JsonPipe, LowerCasePipe, UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { SummaryPipe } from '../summary.pipe';

@Component({
  selector: 'app-builtinpipes',
  imports: [UpperCasePipe,CurrencyPipe,LowerCasePipe,DatePipe,JsonPipe,SummaryPipe,CommonModule],
  templateUrl: './builtinpipes.component.html',
  styleUrl: './builtinpipes.component.css'
})
export class BuiltinpipesComponent {

   product = {

           "name": "Daikin 1.5 Ton 5 Star Inverter Split AC (Copper, PM 2.5 Filter, MTKM50U, White)",
           "price": 45000,
           "seller": "Daikin Manufacturers", 
           "currentdate": new Date(),
           "description":"split ac with inverter swing compressor and hepta sense: high iseer(5.2); dew clean technology for better cleaning of indoor unit and odour free fresh air. capacity 1.5 ton: suitable for medium sized rooms (111 to 150 sq.ft), 5 star: best in class efficiency; iseer value 5.2. warranty: 1 years on product, 5 years on pcb, 10 years on compressor. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. special features: auto variable speed, triple display (power consumption %age, set/room temperature & auto error code); 3d airflow for uniform cooling and pm 2.5 filter. split ac with inverter swing compressor and hepta sense: high iseer(5.2); dew clean technology for better cleaning of indoor unit and odour free fresh air. capacity 1.5 ton: suitable for medium sized rooms (111 to 150 sq.ft), 5 star: best in class efficiency; iseer value 5.2. warranty: 1 years on product, 5 years on pcb, 10 years on compressor. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. special features: auto variable speed, triple display (power consumption %age, set/room temperature & auto error code); 3d airflow for uniform cooling and pm 2.5 filter.split ac with inverter swing compressor and hepta sense: high iseer(5.2); dew clean technology for better cleaning of indoor unit and odour free fresh air. capacity 1.5 ton: suitable for medium sized rooms (111 to 150 sq.ft), 5 star: best in class efficiency; iseer value 5.2. warranty: 1 years on product, 5 years on pcb, 10 years on compressor. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. special features: auto variable speed, triple display (power consumption %age, set/room temperature & auto error code); 3d airflow for uniform cooling and pm 2.5 filter.split ac with inverter swing compressor and hepta sense: high iseer(5.2); dew clean technology for better cleaning of indoor unit and odour free fresh air. capacity 1.5 ton: suitable for medium sized rooms (111 to 150 sq.ft), 5 star: best in class efficiency; iseer value 5.2. warranty: 1 years on product, 5 years on pcb, 10 years on compressor. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. special features: auto variable speed, triple display (power consumption %age, set/room temperature & auto error code); 3d airflow for uniform cooling and pm 2.5 filter.split ac with inverter swing compressor and hepta sense: high iseer(5.2); dew clean technology for better cleaning of indoor unit and odour free fresh air. capacity 1.5 ton: suitable for medium sized rooms (111 to 150 sq.ft), 5 star: best in class efficiency; iseer value 5.2. warranty: 1 years on product, 5 years on pcb, 10 years on compressor. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. special features: auto variable speed, triple display (power consumption %age, set/room temperature & auto error code); 3d airflow for uniform cooling and pm 2.5 filter.split ac with inverter swing compressor and hepta sense: high iseer(5.2); dew clean technology for better cleaning of indoor unit and odour free fresh air. capacity 1.5 ton: suitable for medium sized rooms (111 to 150 sq.ft), 5 star: best in class efficiency; iseer value 5.2. warranty: 1 years on product, 5 years on pcb, 10 years on compressor. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. copper condenser coil with patented dnns self heal coating for low maintenance & enhanced durability. special features: auto variable speed, triple display (power consumption %age, set/room temperature & auto error code); 3d airflow for uniform cooling and pm 2.5 filter"
   }

    readMore = false;

    toggleReadMore(){
       this.readMore = true;
    }

    toggleReadLess(){
       this.readMore = false;
    }

}
