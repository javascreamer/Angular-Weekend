import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'summary'
})
export class SummaryPipe implements PipeTransform {
  transform(value: unknown, ...args: unknown[]): unknown {
     console.log("value", value);
    return  (value as string).substring(0,100);
  }

}
