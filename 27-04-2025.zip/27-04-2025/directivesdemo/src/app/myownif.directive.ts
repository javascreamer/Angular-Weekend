import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appMyownif]'
})
export class MyownifDirective {

  constructor(private templateRef:TemplateRef<any>, private viewContainerRef: ViewContainerRef) {

   }

   @Input() set appMyownif(shouldAddToDOM: boolean){

       if(shouldAddToDOM){
          this.viewContainerRef.createEmbeddedView(this.templateRef);
       }
       else{
          this.viewContainerRef.clear();
       }

   }


}
