import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { StructuralComponent } from './structural/structural.component';
import { AttributeComponent } from './attribute/attribute.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, StructuralComponent,AttributeComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'directivesdemo';
}
