import { MyownifDirective } from './myownif.directive';

describe('MyownifDirective', () => {
  it('should create an instance', () => {
    const directive = new MyownifDirective();
    expect(directive).toBeTruthy();
  });
});
