import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-attribute',
  imports: [FormsModule,CommonModule],
  templateUrl: './attribute.component.html',
  styleUrl: './attribute.component.css'
})
export class AttributeComponent {

   class1 = false; 
   class2 = true; 
   class3 = true;
   bgColor = "yellow";
   textAlign= "center";

}
