import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MyownifDirective } from '../myownif.directive';

@Component({
  selector: 'app-structural',
  imports: [CommonModule,FormsModule,MyownifDirective],
  templateUrl: './structural.component.html',
  styleUrl: './structural.component.css'
})
export class StructuralComponent {

    products:any = []; 

     fetchProducts(){
       this.products = [{
            id:101,
            name: "abc"
       },
      
       {
        id:102,
        name: "xyz"
   },
   {
    id:103,
    name: "hgh"
}
      ];
     }


     addProduct(){

       this.products.push({
             id:104, 
             name:"product 4"
       })

     }

     choice:string = "";
     switchChoice:string = "";

     choiceSubmit(){
        console.log(this.choice);
     }


}
