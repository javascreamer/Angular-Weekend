import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  imports: [FormsModule,CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {


   firstName:any = ""; 
   lastName:any = ""; 
   emailId:any = ""; 
   password:any = ""; 
   mobileNumber:any = ""; 

   constructor(private userService:UserService, private router:Router){

   }

  register(){
var user =
    {
      firstName: this.firstName,
      lastName: this.lastName,
      emailId: this.emailId,
      password: this.password,
      mobileNumber: this.mobileNumber
  }
  console.log(user);

  this.userService.registerUser(user).subscribe(
     (response:any) =>{
                console.log(response);
                if(response.status){
                  
                   this.router.navigateByUrl("/dashboard")

                }
              
     },
      (error) =>{
        console.log(error);
      }
  )
  }

}
