import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authguardGuard: CanActivateFn = (route, state) => {
  var router = inject(Router);
   var result = false;
   var emailId = sessionStorage.getItem("emailId");

    if(emailId != null){
          result = true;
    }
    else{
        router.navigateByUrl("/login");
    }
  return result;
};
