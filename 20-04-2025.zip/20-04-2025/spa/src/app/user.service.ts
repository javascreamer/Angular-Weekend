import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) { }

  registerUser(user:any){
   return this.httpClient.post("http://localhost:3019/api/register",user);
  }

  loginUser(user:any){
    return this.httpClient.post("http://localhost:3019/api/login",user);
  }

}
