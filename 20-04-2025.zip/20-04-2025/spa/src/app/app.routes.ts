import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ContactComponent } from './contact/contact.component';
import { SupportComponent } from './support/support.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import {authguardGuard} from './authguard.guard';

export const routes: Routes = [
    {
        path:"login", 
        component:LoginComponent
    },
    {
        path:"register", 
        component:RegisterComponent
    },
    {
        path:"contact", 
        component:ContactComponent
    },
    {
        path:"support", 
        component:SupportComponent
    },
    {
        path:"dashboard", 
        component: DashboardComponent,
        canActivate: [authguardGuard]
    }
];
