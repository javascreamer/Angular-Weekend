import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  message:any = "";
  
  isLoginFailed:boolean = false;

   constructor(private userService:UserService,private router:Router){

   }

  emailId:any = "";
  password:any = "";
  login(){
    var user =
        {
          emailId: this.emailId,
          password: this.password,
          
      }
      console.log("user",user);

      this.userService.loginUser(user).subscribe(
        (response:any) =>{
             if(response.status){
                      sessionStorage.setItem("emailId", user.emailId);
                   this.router.navigateByUrl("/dashboard");
             }
             else{

              this.message =response.message;
              this.isLoginFailed = true;


             }
        }
      )
    }



  }

