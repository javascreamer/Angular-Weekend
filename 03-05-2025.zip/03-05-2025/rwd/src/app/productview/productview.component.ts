import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productview',
  imports: [CommonModule],
  templateUrl: './productview.component.html',
  styleUrl: './productview.component.css'
})
export class ProductviewComponent implements OnInit{

  product:any = null;

  constructor(private productService:ProductService, private router:Router){

  }
  ngOnInit(): void {

     let productId = localStorage.getItem("productId");

      this.productService.getProductById(productId).subscribe(
         response =>{
          console.log(response);
          this.product = response;
         }
      )

  }

  backToProducts(){

     this.router.navigateByUrl("/products");

  }

}
