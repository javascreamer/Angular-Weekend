import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  imports: [CommonModule],
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent implements OnInit {

  productList:any= [];

  constructor(private productService:ProductService, private router:Router){

  }

  ngOnInit(): void {
     this.productService.getProducts().subscribe(
      response =>{
        console.log(response);
        this.productList = response;
      }
     )
  }

  viewProduct(productId:any){
   console.log("productId", productId);
   localStorage.setItem("productId",productId);
   // redirection logic?
   this.router.navigateByUrl("productview");
  }

  hightolow(){
     console.log("high to low");

      console.log(this.productList);
     this.productList.sort((productx:any,producty:any) =>{
            return producty.productPrice - productx.productPrice
       })

  }
  lowtohigh(){
    console.log("low to high");
    this.productList.sort((productx:any,producty:any) =>{
      return productx.productPrice - producty.productPrice
 })
 }
  

   
  


}
