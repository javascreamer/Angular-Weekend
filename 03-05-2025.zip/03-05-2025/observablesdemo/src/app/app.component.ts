import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Observable } from 'rxjs';
import { PostsComponent } from './posts/posts.component';
import { ProductComponent } from './product/product.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,PostsComponent,ProductComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'observablesdemo';

    
     invoke(){
        console.log("invoke");

         

        var observable = new Observable(
          function(subscriber){
                subscriber.next({
                    score:"121/6"
                });
                  subscriber.next({
                    score:"123/7"
              });
                subscriber.next({
                  score:"134/9"
            });
                  subscriber.next({
                    score:"140/9"
              });
          }
        );


        observable.subscribe(
          {
            next: (response:any) => console.log(response), 
            error: (errorInfo:any) => console.log(errorInfo), 
            complete: () => {console.log("data fetching completed") }

          }
        )

        

     }

}
