import { Component } from '@angular/core';
import { PostService } from '../post.service';

@Component({
  selector: 'app-posts',
  imports: [],
  templateUrl: './posts.component.html',
  styleUrl: './posts.component.css'
})
export class PostsComponent {

   constructor(private postsService:PostService){

   }

   getPosts(){

     this.postsService.getAllPosts().subscribe(
       {
         next: (response:any) => {
                   console.log(response);
         },
         error: (errorInfo:any) => {
                      console.log("error occured");
         },
         complete: () => {console.log("completed")}
       }
     );

   }

}
