import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product',
  imports: [],
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent implements OnInit {

  constructor(private productService:ProductService){

  }

    ngOnInit(): void {
   
        this.productService.getProducts().then((response) =>{
                console.log(response)
        },
      
         (error) =>{
          console.log(error)
         }
       )
      
    }

}
