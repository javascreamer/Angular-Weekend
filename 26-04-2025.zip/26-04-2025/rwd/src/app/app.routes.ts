import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ProductComponent } from './product/product.component';
import { HomeComponent } from './home/home.component';

export const routes: Routes = [
    {
        path:"login", 
        component:LoginComponent
    },
    {
        path:"register", 
        component:RegisterComponent
    },
    {
        path:"products", 
        component:ProductComponent
    },
    {
        path:"", 
        component:HomeComponent
    }
];
